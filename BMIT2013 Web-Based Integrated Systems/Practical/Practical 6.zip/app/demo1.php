<?php
require '_base.php';
//-----------------------------------------------------------------------------

if (is_post()) {
    $f = get_file('photo'); // TODO

    // Validate: photo (file)
    if ($f == null) {
        $_err['photo'] = 'Required';
    }
    else if (!str_starts_with($f->type, 'image/')) { // TODO
        $_err['photo'] = 'Must be image';
    }
    else if ($f->size > 1 * 1024 * 1024) { // TODO
        $_err['photo'] = 'Maximum 1MB';
    }

    if (!$_err) {
        // TODO
        // move_uploaded_file($f->tmp_name, "uploads/$f->name");
        $photo = uniqid().'.jpg';

        require_once 'lib/SimpleImage.php';
        $img = new SimpleImage();
        $img->fromFile($f->tmp_name)
            ->thumbnail(200, 200)
            ->toFile("uploads/$photo", "image/jpeg");

        temp('info', 'Photo uploaded');
        redirect();
    }
}

// ----------------------------------------------------------------------------
$_title = 'Demo 1 | Upload';
include '_head.php';
?>

<form method="post" class="form" enctype="multipart/form-data">
    <label for="photo">Photo</label>

    <label class="upload" tabindex="0">
        <?= html_file('photo', 'image/*', 'hidden') ?>
        <img src="/images/photo.jpg">
    </label>
    <?= err('photo') ?>

    <section>
        <button>Submit</button>
        <button type="reset">Reset</button>
    </section>
</form>

<?php
include '_foot.php';