<?php
require '_base.php';
//-----------------------------------------------------------------------------

if (is_post()) {
    $photo = req('photo');
    
    // TODO
    $photo = basename($photo);
    unlink("uploads/$photo");    

    temp('info', 'Photo deleted');
    redirect('demo2.php');
}

// TODO
$arr = glob('uploads/*.jpg'); 
$arr = array_map('basename', $arr);

// ----------------------------------------------------------------------------
$_title = 'Demo 2 | Browse';
include '_head.php';
?>

<style>
    .photos {
        display: flex;
        gap: 5px;
        flex-wrap: wrap;
    }

    .photos div {
        position: relative;
    }

    .photos img {
        display: block;
        border: 1px solid #333;
        width: 200px;
        height: 200px;
        object-fit: cover;
    }

    .photos button {
        position: absolute;
        inset: 0 0 auto auto;
    }
</style>

<p><?= count($arr) ?> photo(s)</p>

<div class="photos">
    <?php foreach ($arr as $f): ?>
    <div>
        <img src="/uploads/<?= $f ?>">
        <button data-post="?photo=<?= $f ?>">Delete</button>
    </div>
    <?php endforeach ?>
</div>

<?php
include '_foot.php';