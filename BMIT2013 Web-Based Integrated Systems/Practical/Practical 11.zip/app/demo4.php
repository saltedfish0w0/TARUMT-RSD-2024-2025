<?php
include '_base.php';

// ----------------------------------------------------------------------------

// (1) Populate select list items
// TODO
$min = date('Y') -4;
$max = date('Y');
$years  = get_years($min, $max, true);
$months = get_months();

// (2) Inputs and validations
// TODO
$year = req('year');
$month = req('month');

// TODO
if($year < $min || $year > $max) $year = date('Y');
if($month < 1 || $month > 12) $month = date('n');

// (3) Start and end dates
// TODO
$a = new DateTime("$year-$month");
$b = new DateTime("last day of $year-$month");

// (4) Adjustments ($a = Monday, $b = Sunday)
// TODO
if($a->format('N') != 1) $a->modify('previous monday');
if($b->format('N') != 7) $b->modify('next sunday');

// (6) Read holiday records between $a and $b
// TODO
$stm = $_db->prepare('
    SELECT date, h.* FROM holiday AS h WHERE date >= ? AND date <= ?
');
$stm->execute([$a->format('Y-m-d'), $b->format('Y-m-d')]);
$data = $stm->fetchAll(PDO::FETCH_GROUP);

// ----------------------------------------------------------------------------

$_title = 'Demo 4 : Holiday Calendar';
include '_head.php';
?>

<style>
    .cal {
        display: grid;
        grid: auto / repeat(7, 1fr);
        gap: 1px;
    }

    .cal > h3 {
        outline: 1px solid #333;
        margin: 0;
        padding: 5px;
        text-align: center;
        background: #666;
        color: #fff;
    }

    .cal > div {
        outline: 1px solid #333;
        padding: 5px;
        min-height: 75px;
    }

    .cal > div.x {
        background-color: #ccc;
    }
</style>

<form>
    <?= html_select('year',  $years,  null) ?>
    <?= html_select('month', $months, null) ?>
</form>

<br>

<div class="cal">
    <h3>Monday</h3>
    <h3>Tuesday</h3>
    <h3>Wednesday</h3>
    <h3>Thursday</h3>
    <h3>Friday</h3>
    <h3>Saturday</h3>
    <h3>Sunday</h3>

    <?php
    // (5) Display each day between $a and $b
    // (7) Display holiday name (if any)
    // TODO

    for($d = clone $a; $d <= $b; $d->modify('+1day')){
        $c = $d->format('n') != $month ? 'x' : '';

        echo "<div class='$c'>";
        echo "<b>{$d->format('d')}</b><br>";

        $key = $d->format('Y-m-d');
        foreach($data[$key] ?? [] as $h){
            echo "- $h->name<br>";
        }

        echo "</div>";
    }
    ?>
</div>

<script>
    $('select').on('change', e => $(e.target.form).submit());
</script>

<?php
include '_foot.php';