<?php
include '_base.php';

// ----------------------------------------------------------------------------

if (is_post()) {
    // (1) Handle multiple ids
    // TODO
    $id = req('id');
    if(!is_array($id)) $id = [$id];

    $stm = $_db->prepare('DELETE FROM holiday WHERE id = ?');
    $n = 0;

    // (2) Delete mutiple records
    // TODO    
    foreach($id as $v){
        $n += $stm->execute([$v]);
    }
    
    temp('info', "$n record(s) deleted");
}

redirect('demo3.php');

// ----------------------------------------------------------------------------
