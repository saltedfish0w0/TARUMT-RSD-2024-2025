<?php
include '_base.php';

// ----------------------------------------------------------------------------

if (is_post()) {
    // (1) Truncate table
    // TODO
    $_db->query('TRUNCATE holiday');

    $stm = $_db->prepare('INSERT INTO holiday (date, name) VALUES (?, ?)');
    $n = 0;

    // (2) Insert records from CSV file
    // TODO
    $f = fopen('holiday.csv', 'r');
    while($data = fgetcsv($f)){
        $n += $stm->execute($data);
    }
    fclose($f);

    temp('info', "$n record(s) restored");
}

redirect('demo3.php');

// ----------------------------------------------------------------------------
