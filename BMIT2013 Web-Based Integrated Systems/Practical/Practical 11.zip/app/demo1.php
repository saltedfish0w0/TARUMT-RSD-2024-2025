<?php
include '_base.php';

// ----------------------------------------------------------------------------

// (1) Input date range
// TODO
$d = new DateTime('today');
$min = $d->format('Y-m-d');
$max = $d->modify('+14 days')->format('Y-m-d');

if (is_post()) {
    $date = req('date');
    $time = req('time');

    // Validate: date
    if ($date == '') {
        $_err['date'] = 'Required';
    }
    else if (!is_date($date)) { // TODO
        $_err['date'] = 'Invalid date';
    }
    else if ($date < $min || $date > $max) { // TODO
        $_err['date'] = "Must between $min to $max";
    }

    // Validate: time
    if ($time == '') {
        $_err['time'] = 'Required';
    }
    else if (!is_time($time)) { // TODO
        $_err['time'] = 'Invalid time';
    }
    else if ($time < '09:00'|| $time > '17:00') { // TODO
        $_err['time'] = 'Must between 9am to 5pm';
    }

    if (!$_err) {
        $output = "Date = $date. Time = $time";
    }
}

// ----------------------------------------------------------------------------

$_title = 'Demo 1 : DateTime Input';
include '_head.php';
?>

<form method="post" class="form" novalidate>
    <label for="date">Date</label>
    <!-- (2) Date picker -->
    <?= html_date('date', $min, $max) // TODO ?>
    <?= err('date') ?>

    <label for="time">Time</label>
    <!-- (3) Time picker -->
    <?= html_time('time') // TODO ?>
    <?= err('time') ?>

    <section>
        <button>Submit</button>
        <button type="reset">Reset</button>
    </section>
</form>

<p><?= $output ?? '' ?></p>

<?php
include '_foot.php';