<?php
include '_base.php';

// ----------------------------------------------------------------------------

$items = [
    'APP' => 'Apple',
    'BNN' => 'Banana',
    'CCN' => 'Coconut',
    'DRN' => 'Durian',
];

if (is_post()) {
    // (2) Read fruits[]
    $fruits = req('fruits', []); // TODO

    // (3) Validate fruits[]
    if (!$fruits) { // TODO
        $_err['fruits'] = 'Required';
    }
    else if (!is_array($fruits)) { // TODO
        $_err['fruits'] = 'Not an array';
    }
    else if (!array_all($fruits, fn($v) => key_exists($v, $items))) { // TODO
        $_err['fruits'] = 'Invalid item found';
    }
    else if (count($fruits) < 2) { // TODO
        $_err['fruits'] = 'Minimum 2 fruits';
    }

    if (!$_err) {
        $output = 'You have selected: ' . implode(', ', $fruits);
    }
}

// ----------------------------------------------------------------------------

$_title = 'Demo 5 : Checkbox List (EXTRA)';
include '_head.php';
?>

<form method="post" class="form">
    <label for="fruits">Fruits</label>
    <!-- (1) Checkbox list -->
    <?= html_checkboxes('fruits', $items, true) // TODO ?>
    <?= err('fruits') ?>

    <section>
        <button>Submit</button>
        <button type="reset">Reset</button>
    </section>
</form>

<p><?= $output ?? '' ?></p>

<?php
include '_foot.php';