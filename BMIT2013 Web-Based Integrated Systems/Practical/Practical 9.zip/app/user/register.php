<?php
include '../_base.php';

// ----------------------------------------------------------------------------



// ----------------------------------------------------------------------------

$_title = 'User | Register Member';
include '../_head.php';
?>

<p>Removed for brevity</p>

<?php
include '../_foot.php';