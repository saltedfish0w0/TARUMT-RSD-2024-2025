<?php
include '../_base.php';

// ----------------------------------------------------------------------------



// ----------------------------------------------------------------------------

$_title = 'User | Reset Password';
include '../_head.php';
?>

<p>Removed for brevity</p>

<?php
include '../_foot.php';