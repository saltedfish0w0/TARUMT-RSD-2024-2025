<?php
include '_base.php';

// ----------------------------------------------------------------------------



// ----------------------------------------------------------------------------

$_title = 'Index';
include '_head.php';
?>

<table class="table">
    <tr>
        <th>Email</th>
        <th>Password</th>
        <th>Role</th>
    </tr>
    <tr>
        <td>1@gmail.com</td>
        <td>123456</td>
        <td>Admin</td>
    </tr>
    <tr>
        <td>2@gmail.com</td>
        <td>123456</td>
        <td>Member</td>
    </tr>
</table>

<?php
include '_foot.php';