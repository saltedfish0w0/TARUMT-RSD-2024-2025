<?php
require '_base.php';
//-----------------------------------------------------------------------------

$program_id = req('program_id');

// TODO
$stm = $_db->prepare('SELECT * FROM student WHERE program_id = ? OR ?');
$stm->execute([$program_id, $program_id == null]);
$arr= $stm->fetchAll();

// ----------------------------------------------------------------------------
$_title = 'Demo 2 | Filtering';
include '_head.php';
?>

<p>
    <a href="?">All</a>
    <?php
    foreach ($_programs as $id => $name) {
        echo " | <a href='?program_id=$id'>$id</a>";
    }
    ?>
</p>

<p><?= count($arr) ?> record(s)</p>

<table class="table">
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Gender</th>
        <th>Program</th>
    </tr>

    <?php foreach ($arr as $s): ?>
    <tr>
        <td><?= $s->id ?></td>
        <td><?= $s->name ?></td>
        <td><?= $s->gender ?></td>
        <td><?= $s->program_id ?></td>
    </tr>
    <?php endforeach ?>
</table>

<?php
include '_foot.php';