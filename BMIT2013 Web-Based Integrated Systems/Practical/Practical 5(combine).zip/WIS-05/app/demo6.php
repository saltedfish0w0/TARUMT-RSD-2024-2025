<?php
require '_base.php';
//-----------------------------------------------------------------------------

// (1) Sorting
$fields = [
    'id'         => 'Id',
    'name'       => 'Name',
    'gender'     => 'Gender',
    'program_id' => 'Program',
];

$sort = req('sort');
key_exists($sort, $fields) || $sort = 'id';

$dir = req('dir');
in_array($dir, ['asc', 'desc']) || $dir = 'asc';

// (2) Paging
$page = req('page', 1);
$name = req('name');
$program_id = req('program_id');

require_once 'lib/SimplePager.php';
$p = new SimplePager("SELECT * FROM student WHERE name LIKE ? 
                     AND (program_id = ? OR ? ) ORDER BY $sort $dir", ["%$name%", $program_id, $program_id == null], 10, $page);
$arr = $p->result;

// ----------------------------------------------------------------------------
$_title = 'Demo 6 | Combined';
include '_head.php';
?>

<form>
    <?= html_search('name') ?>
    <?= html_select('program_id', $_programs, 'All') ?>
    <button>Search</button>
</form>

<p>
    <?= $p->count ?> of <?= $p->item_count ?> record(s) |
    Page <?= $p->page ?> of <?= $p->page_count ?>
</p>

<table class="table">
    <tr>
        <!-- TODO -->
        <?= table_headers($name, $program_id, $fields, $sort, $dir, "page=$page") ?>
    </tr>

    <?php foreach ($arr as $s): ?>
    <tr>
        <td><?= $s->id ?></td>
        <td><?= $s->name ?></td>
        <td><?= $s->gender ?></td>
        <td><?= $s->program_id ?></td>
    </tr>
    <?php endforeach ?>
</table>

<br>

<!-- TODO -->
<?= $p->html("name=$name&program_id=$program_id&sort=$sort&dir=$dir") ?>

<?php
include '_foot.php';