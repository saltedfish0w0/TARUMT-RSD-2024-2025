<?php
require '../_base.php';

$_title = 'Page | Demo 1';
include '../_head.php';
?>

<h1><?= $_title ?? 'Untitled' ?></h1>

<p>Demo 1</p>

<button data-get="/">Index</button>
<button data-get="/page/demo1.php">Demo 1</button>
<button data-get="demo1.php">Demo 1</button>
<button data-get>Reload</button>
<span data-get="https://www.tarc.edu.my">TAR UMT</span>

<style>
    #img {
        width: 600px;
        height: 400px;
        border: 10px solid #fff;
        box-shadow: 0 0 5px #000;
        border-radius: 5px;
        cursor: pointer;
    }
</style>

<p id="p">Image 1 of 4</p>
<img id="img" src="/images/1.jpg">

<script>
    const arr = [
        '/images/1.jpg',
        '/images/2.jpg',
        '/images/3.jpg',
        '/images/4.jpg',
    ];

    let i = 0;

    $('#img').on('click', e => {
        i = ++i % arr.length;

        $('#p').text(`Image ${i + 1} of 4`);

        $('#img')
            .hide()
            .prop('src', arr[i])
            .fadeIn();
    });
</script>

<?php
include '../_foot.php';
?>