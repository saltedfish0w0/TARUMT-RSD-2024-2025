<?php
require '../_base.php';
// ----------------------------------------------------------------------------

// TODO
$s = temp('data');

if(!$s){
    temp('info', 'Fill and submit the form');
    redirect('demo2.php');
}

// ----------------------------------------------------------------------------
$_title = 'Page | Demo 3';
include '../_head.php';
?>

<form class="form">
    <label>Id</label>
    <span><?= $s -> id ?></span>
    <br>

    <label>Name</label>
    <span><?= $s -> name ?></span>
    <br>

    <label>Gender</label>
    <span>
        <?= $s -> gender ?> -
        <?= $_genders[$s -> gender] ?>
    </span>
    <br>

    <label>Program</label>
    <span>
        <?= $s -> program_id ?> -
        <?= $_programs[$s -> program_id] ?>
    </span>
    <br>
</form>

<?php
include '../_foot.php';