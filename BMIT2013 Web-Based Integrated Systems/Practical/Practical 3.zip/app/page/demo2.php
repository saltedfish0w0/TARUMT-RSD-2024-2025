<?php
require '../_base.php';
// ----------------------------------------------------------------------------

if (is_post()) {
    // TODO
    $id = req('id');
    $name = req('name');
    $gender = req('gender');
    $program_id = req('program_id');

    //validate id
    if($id == ''){
        $_err['id'] = 'Required';
    }
    else if(!preg_match('/^\d{2}[A-Z]{3}\d{5}$/', $id)){
        $_err['id'] = 'Invalid Format';
    }

    //Validate form
    if($name == ''){
        $_err['name'] = 'Required';
    }
    else if(strlen($name) > 100){
        $_err['name'] = 'Maximum length 100';
    }

    //Validate gender
    if($gender == ''){
        $_err['gender'] = 'Required';
    }
    else if(!array_key_exists($gender, $_genders)){
        $_err['gender'] = 'Invalid value';
    }

    //Validate program_id
    if($program_id == ''){
        $_err['program_id'] = 'Required';
    }
    else if(!array_key_exists($program_id, $_programs)){
        $_err['program_id'] = 'Invalid value';
    }

    //Output
    if(!$_err){
        temp('info', "Submitted $id, $name, $gender, $program_id");

        $data = (object)compact('id', 'name', 'gender', 'program_id');
        temp('data', $data);
        
        redirect('demo3.php');
    }

}

// ----------------------------------------------------------------------------
$_title = 'Page | Demo 2';
include '../_head.php';
?>

<form method="post" class="form">
    <label for="id">Id</label>
    <?= html_text('id', 'maxlength="10" data-upper') ?>
    <?= err('id') ?>

    <label for="name">Name</label>
    <?= html_text('name', 'maxlength="100"') ?>
    <?= err('name') ?>

    <label for="gender">Gender</label>
    <?= html_radios('gender', $_genders) ?>
    <?= err('gender') ?>

    <label for="program_id">Program</label>
    <?= html_select('program_id', $_programs) ?>
    <?= err('program_id') ?>
    
    <section>
        <button>Submit</button>
        <button type="reset">Reset</button>
    </section>
</form>

<?php
include '../_foot.php';