<?php
require '../_base.php';
// ----------------------------------------------------------------------------

if (is_post()) {
    // TODO
    temp('info', 'Redirected from Demo 1');
    redirect('/');
}

// ----------------------------------------------------------------------------
$_title = 'Page | Demo 1';
include '../_head.php';
?>

<form method="post">
    <button>Submit</button>
</form>

<?php
include '../_foot.php';
?>