<?php
require '_base.php';
// ----------------------------------------------------------------------------

if (is_post()) {
    // TODO

    $id = req('id');

    $stm = $_db->prepare('DELETE FROM student WHERE id = ?');
    $stm->execute([$id]);

    temp('info', 'Record deleted');
    redirect('/');
}

// TODO