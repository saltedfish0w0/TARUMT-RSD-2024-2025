<?php
require '_base.php';
//-----------------------------------------------------------------------------

// TODO
$arr = $_db->query('SELECT * FROM student') -> fetchAll();

// ----------------------------------------------------------------------------
$_title = 'Index';
include '_head.php';
?>

<p><?= count($arr) ?> record(s)</p>

<table class="table">
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Gender</th>
        <th>Program</th>
        <th></th>
    </tr>

    <?php foreach ($arr as $s): ?>
    <tr>
        <td><?= $s->id ?></td>
        <td><?= $s->name ?></td>
        <td><?= $s->gender ?></td>
        <td><?= $s->program_id ?></td>
        <td>
            <!-- TODO -->
            <button  data-get="detail.php?id=<?= $s -> id?>">Detail</button>
            <button  data-get="update.php?id=<?= $s -> id?>">Update</button>
            <button data-post="delete.php?id=<?= $s -> id?>" data-confirm="Delete this record?">Delete</button>
        </td>
    </tr>
    <?php endforeach ?>
</table>

<?php
include '_foot.php';