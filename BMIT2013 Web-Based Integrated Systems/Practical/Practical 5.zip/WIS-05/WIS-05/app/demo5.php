<?php
require '_base.php';
//-----------------------------------------------------------------------------

$page = req('page', 1);

// TODO
require_once 'lib/SimplePager.php';
$p = new SimplePager('SELECT * FROM student', [], 10, $page);
$arr = $p->result;

// ----------------------------------------------------------------------------
$_title = 'Demo 5 | Paging';
include '_head.php';
?>

<p>
    <?= $p->count ?> of <?= $p->item_count ?> record(s) |
    Page <?= $p->page ?> of <?= $p->page_count ?>
</p>

<table class="table">
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Gender</th>
        <th>Program</th>
    </tr>

    <?php foreach ($arr as $s): ?>
    <tr>
        <td><?= $s->id ?></td>
        <td><?= $s->name ?></td>
        <td><?= $s->gender ?></td>
        <td><?= $s->program_id ?></td>
    </tr>
    <?php endforeach ?>
</table>

<br>

<?= $p->html() ?>

<?php
include '_foot.php';