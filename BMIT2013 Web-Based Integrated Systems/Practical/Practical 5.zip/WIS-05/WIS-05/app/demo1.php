<?php
require '_base.php';
//-----------------------------------------------------------------------------

$name = req('name');

// TODO
$stm = $_db->prepare('SELECT * FROM student WHERE name LIKE ?');
$stm->execute(["%$name%"]);
$arr= $stm->fetchAll();

// ----------------------------------------------------------------------------
$_title = 'Demo 1 | Searching';
include '_head.php';
?>

<form>
    <?= html_search('name') ?>
    <button>Search</button>
</form>

<p><?= count($arr) ?> record(s)</p>

<table class="table">
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Gender</th>
        <th>Program</th>
    </tr>

    <?php foreach ($arr as $s): ?>
    <tr>
        <td><?= $s->id ?></td>
        <td><?= $s->name ?></td>
        <td><?= $s->gender ?></td>
        <td><?= $s->program_id ?></td>
    </tr>
    <?php endforeach ?>
</table>

<?php
include '_foot.php';