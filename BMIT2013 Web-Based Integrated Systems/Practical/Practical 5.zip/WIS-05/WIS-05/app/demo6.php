<?php
require '_base.php';
//-----------------------------------------------------------------------------

// (1) Sorting
$fields = [
    'id'         => 'Id',
    'name'       => 'Name',
    'gender'     => 'Gender',
    'program_id' => 'Program',
];

$sort = req('sort');
key_exists($sort, $fields) || $sort = 'id';

$dir = req('dir');
in_array($dir, ['asc', 'desc']) || $dir = 'asc';

// (2) Paging
$page = req('page', 1);

require_once 'lib/SimplePager.php';
$p = new SimplePager("SELECT * FROM student ORDER BY $sort $dir", [], 10, $page);
$arr = $p->result;

// ----------------------------------------------------------------------------
$_title = 'Demo 6 | Combined';
include '_head.php';
?>

<p>
    <?= $p->count ?> of <?= $p->item_count ?> record(s) |
    Page <?= $p->page ?> of <?= $p->page_count ?>
</p>

<table class="table">
    <tr>
        <!-- TODO -->
        <?= table_headers($fields, $sort, $dir, "page=$page") ?>
    </tr>

    <?php foreach ($arr as $s): ?>
    <tr>
        <td><?= $s->id ?></td>
        <td><?= $s->name ?></td>
        <td><?= $s->gender ?></td>
        <td><?= $s->program_id ?></td>
    </tr>
    <?php endforeach ?>
</table>

<br>

<!-- TODO -->
<?= $p->html("sort=$sort&dir=$dir") ?>

<?php
include '_foot.php';