<?php
require '_base.php';
//-----------------------------------------------------------------------------

$name = req('name');
$program_id = req('program_id');

// TODO
$stm = $_db->prepare('SELECT * FROM student
                        WHERE name LIKE ?
                        AND (program_id = ? OR ?)');
$stm->execute(["%$name%", $program_id, $program_id == null]);
$arr= $stm->fetchAll();

// ----------------------------------------------------------------------------
$_title = 'Demo 3 | Combined';
include '_head.php';
?>

<form>
    <?= html_search('name') ?>
    <?= html_select('program_id', $_programs, 'All') ?>
    <button>Search</button>
</form>

<p><?= count($arr) ?> record(s)</p>

<table class="table">
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Gender</th>
        <th>Program</th>
    </tr>

    <?php foreach ($arr as $s): ?>
    <tr>
        <td><?= $s->id ?></td>
        <td><?= $s->name ?></td>
        <td><?= $s->gender ?></td>
        <td><?= $s->program_id ?></td>
    </tr>
    <?php endforeach ?>
</table>

<?php
include '_foot.php';