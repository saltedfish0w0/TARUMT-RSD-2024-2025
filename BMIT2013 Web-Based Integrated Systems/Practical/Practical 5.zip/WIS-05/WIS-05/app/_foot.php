    </main>

    <footer>
        Developed by <b>BAE SUZY</b> &middot;
        Copyrighted &copy; <?= date('Y') ?>
    </footer>
</body>
</html>