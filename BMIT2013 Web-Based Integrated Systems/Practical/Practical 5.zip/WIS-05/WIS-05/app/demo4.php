<?php
require '_base.php';
//-----------------------------------------------------------------------------

$fields = [
    'id'         => 'Id',
    'name'       => 'Name',
    'gender'     => 'Gender',
    'program_id' => 'Program',
];

// TODO
$sort = req('sort');
key_exists($sort, $fields) || $sort = 'id';

$dir = req('dir');
in_array($dir, ['asc', 'desc']) || $dir = 'asc';

$arr = $_db->query("SELECT * FROM student ORDER BY $sort $dir")->fetchAll();

// ----------------------------------------------------------------------------
$_title = 'Demo 4 | Sorting';
include '_head.php';
?>

<p><?= count($arr) ?> record(s)</p>

<table class="table">
    <tr>
        <?= table_headers($fields, $sort, $dir) ?>
    </tr>

    <?php foreach ($arr as $s) : ?>
        <tr>
            <td><?= $s->id ?></td>
            <td><?= $s->name ?></td>
            <td><?= $s->gender ?></td>
            <td><?= $s->program_id ?></td>
        </tr>
    <?php endforeach ?>
</table>

<?php
include '_foot.php';
