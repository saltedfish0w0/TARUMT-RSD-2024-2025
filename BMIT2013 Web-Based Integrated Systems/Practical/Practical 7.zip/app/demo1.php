<?php
include '_base.php';

// ----------------------------------------------------------------------------

// Authenticated users
// TODO
auth();

if (is_post()) {
    $btn = req('btn');

    // TODO
    if ($btn == 'a' && 1) {
        temp('info', 'Admin button clicked');
    }
    
    if ($btn == 'm' && 1) {
        temp('info', 'Member button clicked');
    }
}

// ----------------------------------------------------------------------------

$_title = 'Demo 1';
include '_head.php';
?>

<p>Authenticated users.</p>

<form method="post">
    <!-- TODO -->
    <?php if ($_user->role == 'Admin'): ?>
        <button name="btn" value="a">Admin</button>
    <?php endif ?>

    <?php if ($_user->role == 'Member'): ?>
        <button name="btn" value="m">Member</button>
    <?php endif ?>
</form>

<?php
include '_foot.php';