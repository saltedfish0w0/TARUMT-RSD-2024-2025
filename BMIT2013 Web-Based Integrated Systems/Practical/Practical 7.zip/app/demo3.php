<?php
include '_base.php';

// ----------------------------------------------------------------------------

// Member role
// TODO
auth('Member');

// ----------------------------------------------------------------------------

$_title = 'Demo 3';
include '_head.php';
?>

<p>Member role.</p>

<?php
include '_foot.php';