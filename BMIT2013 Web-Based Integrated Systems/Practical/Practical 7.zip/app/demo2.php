<?php
include '_base.php';

// ----------------------------------------------------------------------------

// Admin role
// TODO
auth('Admin');

// ----------------------------------------------------------------------------

$_title = 'Demo 2';
include '_head.php';
?>

<p>Admin role.</p>

<?php
include '_foot.php';